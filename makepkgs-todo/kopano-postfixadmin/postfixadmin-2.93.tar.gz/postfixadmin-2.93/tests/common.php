<?php

ini_set('include_path', ini_get('include_path') . ':' . dirname(__FILE__) . '/../');
require_once(dirname(__FILE__) . '/../common.php');

/* vim: set expandtab softtabstop=4 tabstop=4 shiftwidth=4: */
